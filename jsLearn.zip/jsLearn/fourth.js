const changecolor = document.querySelector("#changecolor");

function getRandomColor() {
    return `rgb(${Math.floor(Math.random() * 256)}, ${Math.floor(Math.random() * 256)},${Math.floor(Math.random() * 256)})`;
    
}

changecolor.addEventListener("click", (event) => {
  document.body.style.backgroundColor = getRandomColor();
});
