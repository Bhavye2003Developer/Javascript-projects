//xhr method
const API = `https://ron-swanson-quotes.herokuapp.com/v2/quotes`
const quoteHeading = document.getElementById("quote")

// const xhrobj = new XMLHttpRequest()
// xhrobj.open("GET",API)

// xhrobj.onreadystatechange = ()=>{
//     // console.log(xhrobj.readyState)
//     if (xhrobj.readyState===4){
//         const response = JSON.parse(xhrobj.response)
//         quoteHeading.innerText = response[0]
//     }
// }
// xhrobj.send()


async function getQuotes(){
    const response = await fetch(API)
    console.log(response)
}
const ans = getQuotes()
console.log(ans)



//fetch method
// const data = fetch(API)
// data.then((response)=>{
//     return response.json()
// }).then((json)=>{
//     // console.log(json)
//     quoteHeading.innerText = json
// })