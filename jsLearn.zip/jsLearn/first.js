"use strict";

var a = document.getElementById("login");
a.onclick = function () {
  var x = prompt("Please enter your password");
  document.getElementsByTagName("h1").item(0).style.visibility = "visible";
  if (x == "Bhavye") {
    document.getElementsByTagName("h1").item(0).style.color = "green";
    document.getElementsByTagName("h1").item(0).innerText = "Welcome Master...";
    a.innerText = "Logout"
    a.style.backgroundColor = "black"
    a.style.color = "green"
    a.style.fontSize = '20px'
  
  } else {
    document.getElementsByTagName("h1").item(0).style.color = "red";
    document.getElementsByTagName("h1").item(0).innerText = "Access Denied!!!";
    a.innerText = "Try Again"
    a.style.backgroundColor = "white"
    a.style.color = "red"
    a.style.fontSize = '20px'
  }
};

let myName = "Bhavye"
let myAge = 22
let aboutMe = `My name is ${myName} and my age is ${myAge}`