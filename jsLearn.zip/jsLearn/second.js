function isEven(number){
    // if (number%2) return false;
    // return true;
    return number%2 ? false : true;
}

function elementIsPresent(arr, target){
    for (let i in arr){
        if (target==arr[i]) return Number(i)+1;
    }
    return -1;
}

// anonymous functions
// const greaterValue = function(number1, number2){
//     return number1>number2 ? number1 : number2
// }


// arrow functions
const greaterValue = (number1, number2) => {
    return number1>number2 ? number1 : number2
}