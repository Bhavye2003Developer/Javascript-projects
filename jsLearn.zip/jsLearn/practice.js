const text = document.getElementById("heading")
let string  = ""

// let temp = prompt("Enter temprature in celcius");
// string = (Number(temp) * (9/5)) + 32;


// let num = prompt("Enter number");
function print_pattern(num){
    string = ""
    for (let i=1; i<=num; i++){
        for (let j=0; j<i; j++){
            string+="* ";
        }
        string+="\n";
    }
    text.innerText  = string
}
// print_pattern(Number(num))

const operation = (num) => {
    if (num[2]=='+') return Number(num[0]) + Number(num[1])
    else if (num[2]=='-'){
        return Number(num[0]) - Number(num[1])
    }
    else if (num[2]=='*'){
        return Number(num[0]) * Number(num[1])
    }
    else if (num[2]=='/' && num[1]!='0'){
        return Number(num[0]) / Number(num[1])
    }
    else if (num[2]=='%' && num[1]!='0'){
        return Number(num[0]) + Number(num[1])
    }
    else{
        return "input is not valid"
    }
}
// string = operation(num.split(" "))

const vowelOrNot = (num) => {
    num = String(num).toLowerCase()
    vowels = [..."aeiou"]
    for (let index in vowels){
        if (vowels[index]==num) return true;
    }
    return false;
}
// string = vowelOrNot(num)

const tableOfNumber = (num) => {
    num = Number(num)
    let string = "";
    for (let i=1; i<=10; i++){
        string+=`${num} x ${i} = ${num*(i)}\n`;
        // console.log(`${num} x ${i} = ${num*Number(i)}\n`);
    }
    return string;
}
// string = tableOfNumber(num)

const primeNumbers = (num) => {
    num = Number(num)
    let string = "";
    let flag;
    for (let i=2; i<=num; i++){
        flag = 0
        for (let j=2; j<i; j++){
            if (i%j==0){
                flag = 1;
                break;
            }
        }
        if (!flag) string+=`${i} `
    }
    return string;
}
// string = primeNumbers(num)

const countNUmberVowels = (num) => {
    num = String(num).toLowerCase();
    let string = 0;
    for (let index in num){
        if (vowelOrNot(num[index])) string++;
    }
    return string;
}
// string = countNUmberVowels(num);

const capitaliseAlternate = (num) => {
    num = String(num).toLowerCase();
    let string = "";
    for (let index in num){
        if (Number(index)%2) string+=String(num[index]).toUpperCase();
        else{
            string+=String(num[index]) 
        }
    }
    return string;
}
// string = capitaliseAlternate(num);

const displayFrequenciesOfElements = (num) => {
    num = String(num).split(" ")
    for (let index in num){
        num[index] = Number(num[index])
    }
    let cnt;
    for (let i=0; i<num.length; i++){
        if (num[i]!='-1'){
            cnt = 1;
            for (let j=i+1; j<num.length; j++){
                if (num[i]==num[j]) {
                    cnt++;
                    num[j] = -1;
                }
            }
            string+=`${num[i]} -> ${cnt}\n`
        }
    }
    return string;
}
// string = displayFrequenciesOfElements(num)


let details = {names:["Neo"],phoneNumbers:[123]};
const userDetails = (details, num) => {
    num = num.split(" ")
    details.names[details['names'].length] = num[0]
    details.phoneNumbers[details['phoneNumbers'].length] = num[1]
    return "Data inserted successfully"
}
// string = userDetails(details, num)

const printDetails = (details) => {
    console.log(details)
    let string = ""
    for (let i=0; i<details['names'].length; i++){
        string+=`${details['names'][i]} -> ${details['phoneNumbers'][i]}\n`
    }
    return string
}
// string = printDetails(details)


var isPalindrome = function(x){
    let num = String(x);
    for (let i=0; i<num.length/2; i++){
        if (num[i]!=num[num.length-i-1]) return false;
    }
    return true;
}

const sBecomesGoal = function(s, goal){
    // not worked for repeated letter at first place in goal
    let goalFirstLetter = goal[0];
    let sGoalFirstLetter = 0;
    for (let i=0; i<s.length; i++){
        if (s[i]==goalFirstLetter){
            sGoalFirstLetter = i;
            break;
        }
    }
    let index = goal.length-1;
    for (let i=sGoalFirstLetter-1; i>=0; i--){
        if (goal[index]!=s[i]) return false;
        index--;
    }
    index = sGoalFirstLetter+1;
    sGoalFirstLetter = 1;
    while (index<s.length){
        if (s[index]!=goal[sGoalFirstLetter]) return false;
        index++;sGoalFirstLetter++;
    }
    return true;
}





text.innerText = string