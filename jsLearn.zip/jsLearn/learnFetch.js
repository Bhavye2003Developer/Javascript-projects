const URL = "https://jsonplaceholder.typicode.com/posts";

console.log("start");

async function myFunc() {
  const response = await fetch(URL);
  const data = await response.json();
  return data;
}

// function myFunc() {
//   const resp = fetch(URL);
//   return resp.then((response)=>{
//     return response.json()
//   });
// }

const data = myFunc();
data.then((result) => {
  for (let index of result) {
    console.log(index);
  }
});

console.log("end");
