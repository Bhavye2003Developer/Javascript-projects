// const obj = ['a','b','c']

// const prom = new Promise((resolve, reject)=>{
//     if (obj.includes('b') && obj.includes('c')){
//         resolve()
//     }
//     else{
//         reject()
//     }
// })


// // prom.then(()=>{
// //     console.log("Hurray"),
// //     ()=>{
// //         console.log("Hell")
// //     }
// // })

// // setTimeout(()=>{
// //     console.log("Hey")
// // },1000)

// // let cnt = 0;
// // const timeOutID = setInterval(()=>{
// //     console.log(cnt)
// //     cnt++;
// //     if (cnt==401) clearInterval(timeOutID);
// // })

// const pr1 = prom.then(()=>{
//     console.log("congo")
// }).catch(()=>{
//     console.log("Error occurs!!!")
// })

// const myPromise = new Promise((resolve, reject)=>{
//     if (true) resolve("Bhavye")
//     else{
//         reject("failed!!!")
//     }
// })

// const prom = myPromise.then((name)=>{
//     console.log(`My name is : ${name}`)
// })
// // .catch((fail)=>{
// //     console.log(`You are ${fail}`)
// // })


function abc(num){
    const myPromise = new Promise((resolve, reject)=>{
        if (num<20) resolve("Bhavye")
        else{
            reject("failed!!!")
        }
    });
    return myPromise;
}
const a = abc(12).then((name)=>{
    console.log(`My name is ${name}`)
    return name+"Jain";
})