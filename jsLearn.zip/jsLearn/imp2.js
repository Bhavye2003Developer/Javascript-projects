// function createUser(firstname, lastname, email, age){
//     let user = Object.create(createUser.prototype);
//     user.firstname = firstname
//     user.lastname = lastname
//     user.email = email
//     user.age = age
//     return user;
// }
// createUser.prototype.about = function(){
//     console.log(`I am ${this.firstname} and my age is ${this.age}`)
// }


// function createUser(firstname, lastname, email, age){
//     this.firstname = firstname
//     this.lastname = lastname
//     this.email = email
//     this.age = age
// }
// createUser.prototype.about = function(){
//     console.log(`I am ${this.firstname} and my age is ${this.age}`)
// }

class createUser{
    constructor(firstname, lastname, email, age){
        this.firstname = firstname
        this.lastname = lastname
        this.email = email
        this.age = age
    }
    about() {
        console.log(`I am ${this.firstname} and my age is ${this.age}`)        
    }
}