function calculate(n){
    function realcalc(a){
        // console.log(`The answer is : ${a**n}`)
        return a**n;
    }
    return realcalc;
}