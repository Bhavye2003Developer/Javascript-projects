// Methods -> func in objects
function printInfo(){
    console.log(`Hey I am ${this.firstname}\nand my age is : ${this.age}`)
}

const user1 = {
    firstname: "Bhavye",
    age: 20
}
const user2 = {
    firstname: "Sam",
    age: 19
}
const user3 = {
    firstname: "Luffy",
    age: 32
}
// printInfo.call(user1)

// this -> current context

// function printElements(){
//     for (let i=0; i<this.length; i++){
//         console.log(i)
//     }
// }
// var arr = [10,20,30,40];


function printUserInfo(){
    console.log(`The user's first name is : ${this.firstname}\nand the age is : ${this.age}`)
}

function createUser(firstname, lastname, email, age){
    let user = {
        "firstname" : firstname,
        "lastname" : lastname,
        "email" : email,
        "age" : age
    }
    return user;
}