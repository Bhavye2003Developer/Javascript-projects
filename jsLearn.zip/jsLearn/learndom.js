const firstHeading = document.querySelector("#firstHeading")
// console.log(firstHeading.textContent)
firstHeading.textContent = "Bhavye"
// console.log(firstHeading.textContent)
firstHeading.style.color = "green"



const ol = document.querySelectorAll(".listItem")
// console.log(ol)
// for (let index of ol){
//     index.style.color = "orange"
// }

ol.forEach((element) => {
    element.style.color = "orange"
})
const firstlistItem = document.querySelector(".listItem")
// console.log(firstlistItem.parentElement)
firstlistItem.parentNode.style.backgroundColor = "green"


const buttonAdd = document.createElement("button")
buttonAdd.textContent = "Submit"
document.querySelector(".mainlist").append(buttonAdd)

// buttonAdd.onclick = function(){
//     console.log("You have clicked...")
// }

buttonAdd.addEventListener("click",function(){
    console.log("You clicked me Bhavye")
})