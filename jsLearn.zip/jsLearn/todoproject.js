const add = document.querySelector("#add")
const entry = document.querySelector("#entrylist")
const entrylist = document.querySelector(".container")

add.addEventListener("click",(e)=>{
    let li = document.createElement("li")
    li.innerHTML = `<p>${entry.value}</p><span><button class="remove">Remove</button><button class="done">Done</button><span>`
    entrylist.append(li)
})

entrylist.addEventListener("click",(event)=>{
    if(event.target.classList[0]==="remove"){
        event.target.parentNode.parentNode.remove()
    }
    else{
        event.target.parentNode.parentNode.querySelector("p").style.color="green"
    }
})